export async function handler(event, context) {
  const now = new Date();
  const utcHour = now.getUTCHours();

  // Convert to Kenyan time (UTC+3)
  const kenyaHour = (utcHour + 3) % 24;

  // Only run between 11 AM and 1 AM Kenyan time
  if (kenyaHour >= 11 || kenyaHour < 1) {
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Bot executed at allowed time." })
    };
  } else {
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Outside allowed hours, bot skipped." })
    };
  }
}