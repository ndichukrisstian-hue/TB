import dotenv from 'dotenv';
dotenv.config();

import { fetchLatestSignal } from '../lib/exchange.js';
import { sendTelegram } from '../lib/notifier.js';

async function run() {
  try {
    const signal = await fetchLatestSignal();
    if (!signal) {
      console.log(new Date().toISOString(), 'No signal found');
      return;
    }

    const message = `Signal: ${signal.side.toUpperCase()} ${signal.symbol} @ ${signal.price}\nReason: ${signal.reason || 'n/a'}`;

    if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
      await sendTelegram(process.env.TELEGRAM_BOT_TOKEN, process.env.TELEGRAM_CHAT_ID, message);
      console.log('Telegram notification sent');
    } else {
      console.log('No notifier configured. Message:');
      console.log(message);
    }
  } catch (err) {
    console.error('Scanner error:', err);
  }
}

if (process.env.NODE_ENV !== 'test') {
  run();
}

export default run;
