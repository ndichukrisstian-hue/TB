# Signal Bot — Final Version

This is the final version of the trading signal bot we built, now updated to run every 3 hours.

## Features
- Scans for signals (mock or from your API).
- Sends Telegram notifications when signals appear.
- Scheduled with GitHub Actions every 3 hours.

## Quick start (local)
1. Copy `.env.example` to `.env` and fill values.
2. Run `npm install`
3. Run `npm start`

## Deployment
- **GitHub Actions**: workflow included (`.github/workflows/scheduler.yml`).
- Set repo secrets for `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, and optionally `EXCHANGE_API_URL`.
